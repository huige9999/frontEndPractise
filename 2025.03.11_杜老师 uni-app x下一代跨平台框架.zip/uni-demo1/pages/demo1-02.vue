<template>
	<view class="wrapper">
		<div class="box1"></div>
		<div class="box2"></div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.box1 {
	width: 100px;
	height: 100px;
	background-color: red;
	float: left;
}
.box2 {
	width: 100px;
	height: 100px;
	background-color: blue;
	float: left;
}
</style>
