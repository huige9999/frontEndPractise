<template>
	<view class="wrapper">
		<div class="box1"></div>
		<div class="box2"></div>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.wrapper {
	display: flex;
}
.box1 {
	width: 100px;
	height: 100px;
	background-color: red;
}
.box2 {
	width: 100px;
	height: 100px;
	background-color: blue;
}
</style>
