<template>
	<view>
		
	</view>
</template>

<script setup lang="ts">
	/* let foo = undefined
	console.log(foo) */
	
	/* foo()
	function foo() {
		console.log('foo')
	} */
	
	/* let foo = (num: number = 123) => {
		console.log(num)
	}
	foo() */
	
	/* let foo = (num?: number) => {
		console.log(num)
	}
	foo() */
	
	/* let foo: number|string = 123
	foo = 'abc' 
	console.log(foo) */

	/* let foo = '123'
	console.log( Number(foo) ) */
	
	/* uni.request({
		url: 'https://jsonplaceholder.typicode.com/todos/1',
		success: (res) => {
			console.log(res.data['id'])
		}
	}) */
</script>

<style>
	       
</style>
