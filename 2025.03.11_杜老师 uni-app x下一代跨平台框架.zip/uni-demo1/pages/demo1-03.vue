<template>
	<view>
		<button @click="handleClick">计数</button>
		<view>{{ count }}, {{ doubleCount }}</view>
	</view>
</template>

<script setup>

import { ref, computed } from 'vue'

const count = ref(0)
const doubleCount = computed(() => count.value * 2)

const handleClick = () => {
	count.value++
}

</script>

<style>
	       
</style>
