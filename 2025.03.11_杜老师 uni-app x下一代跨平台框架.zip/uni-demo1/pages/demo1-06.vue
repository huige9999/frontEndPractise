<template>
	<view>
		
	</view>
</template>

<script setup>
	/* import dayjs from 'dayjs'
	console.log(dayjs(new Date()).format('YYYY')) */
	
	// 不支持原生API调用
	/* import Build from 'android.os.Build'
	console.log(Build.MODEL) */
	
	// 不支持原生数据类型
	/* let foo: Int = 123
	console.log(foo) */
</script>

<style>
	       
</style>
