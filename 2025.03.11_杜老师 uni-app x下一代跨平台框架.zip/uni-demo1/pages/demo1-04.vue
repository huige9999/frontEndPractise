<template>
	<view>
		<button @click="handleClick('abc')">修改数据</button>
		<view>{{ count }}</view>
	</view>
</template>

<script setup>
	import { ref } from 'vue'
	const count = ref(0)
	const handleClick = (num) => {
		count.value = num
	}
</script>

<style>
	       
</style>
