

## 移动端 Web 开发
+ **技术栈：**HTML、CSS、JavaScript（常用框架：Vue、React、jQuery等）。
+ **运行环境：**基于浏览器（如 Safari、Chrome）。
+ **优点： **
    - 开发成本低，一套代码适配所有平台（跨端）。
    - 易于维护和更新（直接更新服务器代码，无需上架应用市场）。
+ **缺点： **
    - 性能较差，尤其是复杂动画、交互和高性能需求场景（如游戏）。
    - 受限于浏览器环境，无法直接调用部分原生能力（如蓝牙、推送等）。
    - 体验不如原生，交互响应可能有延迟。



## iOS/Android 原生开发
+ **技术栈： **
    - iOS：Swift/Objective-C + Xcode
    - Android：Kotlin/Java + Android Studio
+ **运行环境：**直接运行在 iOS 或 Android 系统中。
+ **优点： **
    - 性能最佳，原生应用直接调用系统 API，运行速度快、交互流畅。
    - 深度系统集成，可以直接使用蓝牙、相机、推送、AR等系统功能。
    - 用户体验佳，UI 组件符合平台设计规范（Material Design / Human Interface Guidelines）。
+ **缺点： **
    - 开发成本高，需要分别开发 iOS 和 Android 版本，代码不能复用。
    - 维护成本高，需要跟随系统更新，且发布流程较长（特别是 App Store 审核严格）。



## 混合开发（Hybrid）
主要指 Web + 原生的结合方式，利用JS Bridge实现。 JS Bridge 是JS 和原生（Native）之间通信的桥梁，它允许 JS 调用原生功能（如摄像头、文件系统、网络请求等），也允许原生代码回调 JS。



原生开发一般都内置了混合开发模式，当然跨平台框架一般也都支持混合开发模式。



## 跨平台框架
指的是 能够用同一套代码同时运行在多个平台（iOS、Android、Web、Windows、Mac 等）上的开发框架。它的核心目标是提高开发效率，减少重复开发，同时尽量保证接近原生的体验和性能。  



主要框架有：

+ uni-app
+ react native
+ flutter



主流渲染模式：

+ webview渲染（渲染层） + JS引擎（逻辑层）
+ 原生渲染（渲染层） + JS引擎（逻辑层）
+ 自绘渲染（渲染层 + 逻辑层）



### uni-app
是webview渲染方式。



webview渲染：通过 WebView 组件加载 HTML、CSS、JavaScript 代码，依赖 Web 引擎（如 Chromium、WebKit）。

JS引擎：uni-app的JS引擎在android上是V8，iOS上是JavaScriptCore。

:::info
[微信小程序也是类似的模式。  ](https://developers.weixin.qq.com/miniprogram/dev/framework/quickstart/#%E5%B0%8F%E7%A8%8B%E5%BA%8F%E4%B8%8E%E6%99%AE%E9%80%9A%E7%BD%91%E9%A1%B5%E5%BC%80%E5%8F%91%E7%9A%84%E5%8C%BA%E5%88%AB)

:::



这种方式：性能最低。



### react native
是原生渲染方式，也可以采用webview渲染方式（react-native-webview）。



原生渲染：使用操作系统提供的 原生 UI 组件（如 iOS 的 UIKit、Android 的 View 系统）进行绘制。 

JS引擎：默认使用 Hermes 引擎，之前有V8、JavaScriptCore等。



这种方式：比webview性能要好，但是渲染层和逻辑层不在一起，也会有一定的性能损耗。

:::info
uni-app也支持原生渲染模式。

index.vue -> webview渲染

index.nvue -> [原生渲染](https://uniapp.dcloud.net.cn/tutorial/nvue-outline.html#nvue%E4%BB%8B%E7%BB%8D)（基于weex框架）

:::



### flutter
是自绘渲染方式，也可以采用webview渲染方式（flutter_webview_plugin）。



自绘渲染：不使用原生 UI 组件，而是通过 Skia 2D 图形引擎直接在屏幕上绘制 UI。因为没有JS引擎，所以逻辑采用 Dart 语言。

1. Dart 代码运行在 flutter 引擎中，生成 UI 组件（Widget）。
2. flutter 引擎使用 Skia 直接绘制 UI，而不是调用原生控件。
3. 渲染完成后，Flutter 直接输出到屏幕，绕过了原生 UI 系统。



这种方式：逻辑层和渲染层是在一起的，性能很高，但是自绘渲染还是会有一定的性能损耗的。



## uni-app x
### 概述
DCloud做了很多年跨平台开发，uni-app在web和小程序平台取得了很大的成功，不管规模大小的开发者都在使用； 但在app平台，大开发者只使用uni小程序sdk，中小开发者的app会整体使用。

究其原因，uni-app在web和小程序上，没有性能问题，但是在App端性能确实不好，为了解决uni-app的性能问题，尝试过一些方案，比如：nvue、wxs、renderjs等。

:::info
wxs：是一种运行在视图层的js，它的性能和和灵活性都非常高。

renderjs：也是一种运行在视图层的js。它比wxs更加强大。但是它只支持app-vue和web。

:::



<font style="color:rgb(44, 62, 80);">前面我们讲过，</font>原生开发性能最高<font style="color:rgb(44, 62, 80);">。所以DCloud团队在思考，为什么不直接编译为App平台的原生语言呢？</font>

+ `<font style="color:rgb(233, 105, 0);">web/小程序</font>`平台，编译为JavaScript
+ `<font style="color:rgb(233, 105, 0);">Android</font>`<font style="color:rgb(44, 62, 80);">平台，编译为Kotlin</font>
+ `<font style="color:rgb(233, 105, 0);">iOS</font>`<font style="color:rgb(44, 62, 80);">平台，编译Swift</font>
+ `<font style="color:rgb(233, 105, 0);">鸿蒙next</font>`<font style="color:rgb(44, 62, 80);">平台，编译为ArkTS</font>



<font style="color:rgb(44, 62, 80);">uni-app x 是一个庞大的工程，它包括uts语言、uvue渲染引擎、uni的组件和API、以及扩展机制。uts是一门类ts的、跨平台的、新语言。uts在iOS平台编译为swift、在Android平台编译为kotlin、在Web和小程序平台编译为js、在鸿蒙next平台上编译为ArkTS。</font>

<font style="color:rgb(44, 62, 80);">index.uvue</font>



<font style="color:rgb(44, 62, 80);">uts语言 -> 基于ts开发的语言</font>

<font style="color:rgb(44, 62, 80);"></font>

### <font style="color:rgb(44, 62, 80);">为什么不直接使用TS语言呢？</font>
<font style="color:rgb(44, 62, 80);">为了跨端，uts进行了一些约束和特定平台的增补。A翻译B、C、D其实是一条不归路。因为这些语言设计之初就是为了服务它自己的平台，所以A、B、C、D有很多无法兼容的设计，没办法顺畅翻译。想走这条路的产品也大多被扔进了垃圾桶。</font>

<font style="color:rgb(44, 62, 80);">所以如果开发者期待uts完全兼容ts，那就期待错了。ts直接翻译为kotlin、swift是不现实的。</font>

```javascript
// js code
switch(x) {
  case 1: 
    console.log('a')
  case 2:
    console.log('b')
    break
  default:
    console.log('c')
}
```

```kotlin
// kotlin code
 when (x) {
    1 -> {
        println("a")
        // 注意：Kotlin 的 `when` 语句不会像 JS 那样自动执行下一个 case
        println("b")
    }
    2 -> println("b")
    else -> println("c")
}
```

```swift
// swift code
switch x {
    case 1:
        print("a")
        fallthrough  // Swift 需要显式使用 `fallthrough` 才会继续执行下一个case
    case 2:
        print("b")
    default:
        print("c")
}
```

<font style="color:rgb(44, 62, 80);"></font>

```javascript
// js code
new Proxy(obj, {
  get(target, key) {
    console.log(`获取 ${key}:`, target[key]);
    return target[key];
  },
  set(target, key, value) {
    console.log(`设置 ${key} 为 ${value}`);
    target[key] = value;
    return true;
  }
});
```

```kotlin
// kotlin code
class ReactiveMap<K, V>(private val map: MutableMap<K, V> = mutableMapOf()) {
    private val listeners = mutableListOf<(K, V?) -> Unit>()
    operator fun get(key: K): V? {
        println("获取 $key: ${map[key]}")
        return map[key]
    }
    operator fun set(key: K, value: V) {
        println("设置 $key 为 $value")
        map[key] = value
        listeners.forEach { it(key, value) }
    }
}
```



### 代码演示
通过HBuilder X创建uni-app x项目。

+ uni-app 支持 Vue2、Vue3；uni-app x 只支持 Vue3
+ 图标区别和文件扩展名区别
+ unpackage下编译的产物不同
+ uni-app 支持所有小程序；uni-app x 只支持 微信小程序
+ 暂时不支持Vuex、Pinia
+ ...













