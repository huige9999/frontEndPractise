@file:Suppress("UNCHECKED_CAST", "USELESS_CAST", "INAPPLICABLE_JVM_NAME", "UNUSED_ANONYMOUS_PARAMETER", "NAME_SHADOWING")
package uni.UNI659A61F
import io.dcloud.uniapp.*
import io.dcloud.uniapp.extapi.*
import io.dcloud.uniapp.framework.*
import io.dcloud.uniapp.runtime.*
import io.dcloud.uniapp.vue.*
import io.dcloud.uniapp.vue.shared.*
import io.dcloud.unicloud.*
import io.dcloud.uts.*
import io.dcloud.uts.Map
import io.dcloud.uts.Set
import io.dcloud.uts.UTSAndroid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import io.dcloud.uniapp.extapi.connectSocket as uni_connectSocket
import io.dcloud.uniapp.extapi.exit as uni_exit
import io.dcloud.uniapp.extapi.showToast as uni_showToast
val runBlock1 = run {
    __uniConfig.getAppStyles = fun(): Map<String, Map<String, Map<String, Any>>> {
        return GenApp.styles
    }
}
fun initRuntimeSocket(hosts: String, port: String, id: String): UTSPromise<SocketTask?> {
    if (hosts == "" || port == "" || id == "") {
        return UTSPromise.resolve(null)
    }
    return hosts.split(",").reduce<UTSPromise<SocketTask?>>(fun(promise: UTSPromise<SocketTask?>, host: String): UTSPromise<SocketTask?> {
        return promise.then(fun(socket): UTSPromise<SocketTask?> {
            if (socket != null) {
                return UTSPromise.resolve(socket)
            }
            return tryConnectSocket(host, port, id)
        }
        )
    }
    , UTSPromise.resolve(null))
}
val SOCKET_TIMEOUT: Number = 500
fun tryConnectSocket(host: String, port: String, id: String): UTSPromise<SocketTask?> {
    return UTSPromise(fun(resolve, reject){
        val socket = uni_connectSocket(ConnectSocketOptions(url = "ws://" + host + ":" + port + "/" + id, fail = fun(_) {
            resolve(null)
        }
        ))
        val timer = setTimeout(fun(){
            socket.close(CloseSocketOptions(code = 1006, reason = "connect timeout"))
            resolve(null)
        }
        , SOCKET_TIMEOUT)
        socket.onOpen(fun(e){
            clearTimeout(timer)
            resolve(socket)
        }
        )
        socket.onClose(fun(e){
            clearTimeout(timer)
            resolve(null)
        }
        )
        socket.onError(fun(e){
            clearTimeout(timer)
            resolve(null)
        }
        )
    }
    )
}
fun initRuntimeSocketService(): UTSPromise<Boolean> {
    val hosts: String = "192.168.137.1,192.168.3.64,127.0.0.1"
    val port: String = "8090"
    val id: String = "app-android_6jVmrp"
    if (hosts == "" || port == "" || id == "") {
        return UTSPromise.resolve(false)
    }
    var socketTask: SocketTask? = null
    __registerWebViewUniConsole(fun(): String {
        return "!function(){\"use strict\";function e(e,t){try{return{type:e,args:n(t)}}catch(e){}return{type:e,args:[]}}function n(e){return e.map((function(e){return t(e)}))}function t(e,n){if(void 0===n&&(n=0),n>=7)return{type:\"object\",value:\"[Maximum depth reached]\"};switch(typeof e){case\"string\":return{type:\"string\",value:e};case\"number\":return function(e){return{type:\"number\",value:String(e)}}(e);case\"boolean\":return function(e){return{type:\"boolean\",value:String(e)}}(e);case\"object\":return function(e,n){if(null===e)return{type:\"null\"};if(function(e){return e.\$&&r(e.\$)}(e))return function(e,n){return{type:\"object\",className:\"ComponentPublicInstance\",value:{properties:Object.entries(e.\$.type).map((function(e){return o(e[0],e[1],n+1)}))}}}(e,n);if(r(e))return function(e,n){return{type:\"object\",className:\"ComponentInternalInstance\",value:{properties:Object.entries(e.type).map((function(e){return o(e[0],e[1],n+1)}))}}}(e,n);if(function(e){return e.style&&null!=e.tagName&&null!=e.nodeName}(e))return function(e,n){return{type:\"object\",value:{properties:Object.entries(e).filter((function(e){var n=e[0];return[\"id\",\"tagName\",\"nodeName\",\"dataset\",\"offsetTop\",\"offsetLeft\",\"style\"].includes(n)})).map((function(e){return o(e[0],e[1],n+1)}))}}}(e,n);if(function(e){return\"function\"==typeof e.getPropertyValue&&\"function\"==typeof e.setProperty&&e.\$styles}(e))return function(e,n){return{type:\"object\",value:{properties:Object.entries(e.\$styles).map((function(e){return o(e[0],e[1],n+1)}))}}}(e,n);if(Array.isArray(e))return{type:\"object\",subType:\"array\",value:{properties:e.map((function(e,r){return function(e,n,r){var o=t(e,r);return o.name=\"\".concat(n),o}(e,r,n+1)}))}};if(e instanceof Set)return{type:\"object\",subType:\"set\",className:\"Set\",description:\"Set(\".concat(e.size,\")\"),value:{entries:Array.from(e).map((function(e){return function(e,n){return{value:t(e,n)}}(e,n+1)}))}};if(e instanceof Map)return{type:\"object\",subType:\"map\",className:\"Map\",description:\"Map(\".concat(e.size,\")\"),value:{entries:Array.from(e.entries()).map((function(e){return function(e,n){return{key:t(e[0],n),value:t(e[1],n)}}(e,n+1)}))}};if(e instanceof Promise)return{type:\"object\",subType:\"promise\",value:{properties:[]}};if(e instanceof RegExp)return{type:\"object\",subType:\"regexp\",value:String(e),className:\"Regexp\"};if(e instanceof Date)return{type:\"object\",subType:\"date\",value:String(e),className:\"Date\"};if(e instanceof Error)return{type:\"object\",subType:\"error\",value:e.message||String(e),className:e.name||\"Error\"};var a=void 0,i=e.constructor;i&&i.get\$UTSMetadata\$&&(a=i.get\$UTSMetadata\$().name);return{type:\"object\",className:a,value:{properties:Object.entries(e).map((function(e){return o(e[0],e[1],n+1)}))}}}(e,n);case\"undefined\":return{type:\"undefined\"};case\"function\":return function(e){return{type:\"function\",value:\"function \".concat(e.name,\"() {}\")}}(e);case\"symbol\":return function(e){return{type:\"symbol\",value:e.description}}(e);case\"bigint\":return function(e){return{type:\"bigint\",value:String(e)}}(e)}}function r(e){return e.type&&null!=e.uid&&e.appContext}function o(e,n,r){var o=t(n,r);return o.name=e,o}\"function\"==typeof SuppressedError&&SuppressedError;var a=[\"log\",\"warn\",\"error\",\"info\",\"debug\"],i=null,u=[],c={};function s(e){null!=i?i(JSON.stringify(Object.assign({type:\"console\",data:e},c))):u.push.apply(u,e)}var f=a.reduce((function(e,n){return e[n]=console[n].bind(console),e}),{}),p=/^\\s*at\\s+[\\w/./-]+:\\d+\$/;function l(){function n(n){return function(){for(var t=[],r=0;r<arguments.length;r++)t[r]=arguments[r];var o=function(e,n,t){if(t||2===arguments.length)for(var r,o=0,a=n.length;o<a;o++)!r&&o in n||(r||(r=Array.prototype.slice.call(n,0,o)),r[o]=n[o]);return e.concat(r||Array.prototype.slice.call(n))}([],t,!0);if(o.length){var a=o[o.length-1];\"string\"==typeof a&&p.test(a)&&o.pop()}f[n].apply(f,o),s([e(n,t)])}}return function(){var e=console.log,n=Symbol();try{console.log=n}catch(e){return!1}var t=console.log===n;return console.log=e,t}()?(a.forEach((function(e){console[e]=n(e)})),function(){a.forEach((function(e){console[e]=f[e]}))}):function(){}}var y=null,g=new Set,d={};function v(e){if(null!=y){var n=e.map((function(e){var n=e&&\"promise\"in e&&\"reason\"in e,t=n?\"UnhandledPromiseRejection: \":\"\";if(n&&(e=e.reason),e instanceof Error&&e.stack)return e.message&&!e.stack.includes(e.message)?\"\".concat(t).concat(e.message,\"\\n\").concat(e.stack):\"\".concat(t).concat(e.stack);if(\"object\"==typeof e&&null!==e)try{return t+JSON.stringify(e)}catch(e){return t+String(e)}return t+String(e)})).filter(Boolean);n.length>0&&y(JSON.stringify(Object.assign({type:\"error\",data:n},d)))}else e.forEach((function(e){g.add(e)}))}function m(e){var n={type:\"WEB_INVOKE_APPSERVICE\",args:{data:{name:\"console\",arg:e}}};return window.__uniapp_x_postMessageToService?window.__uniapp_x_postMessageToService(n):window.__uniapp_x_.postMessageToService(JSON.stringify(n))}!function(){if(!window.__UNI_CONSOLE_WEBVIEW__){window.__UNI_CONSOLE_WEBVIEW__=!0;var e=\"[web-view]\".concat(window.__UNI_PAGE_ROUTE__?\"[\".concat(window.__UNI_PAGE_ROUTE__,\"]\"):\"\");l(),function(e,n){if(void 0===n&&(n={}),i=e,Object.assign(c,n),null!=e&&u.length>0){var t=u.slice();u.length=0,s(t)}}((function(e){m(e)}),{channel:e}),function(e,n){if(void 0===n&&(n={}),y=e,Object.assign(d,n),null!=e&&g.size>0){var t=Array.from(g);g.clear(),v(t)}}((function(e){m(e)}),{channel:e}),window.addEventListener(\"error\",(function(e){v([e.error])})),window.addEventListener(\"unhandledrejection\",(function(e){v([e])}))}}()}();"
    }
    , fun(data: String){
        socketTask?.send(SendSocketMessageOptions(data = data))
    }
    )
    return UTSPromise.resolve().then(fun(): UTSPromise<Boolean> {
        return initRuntimeSocket(hosts, port, id).then(fun(socket): Boolean {
            if (socket == null) {
                return false
            }
            socketTask = socket
            return true
        }
        )
    }
    ).`catch`(fun(): Boolean {
        return false
    }
    )
}
val runBlock2 = run {
    initRuntimeSocketService()
}
var firstBackTime: Number = 0
open class GenApp : BaseApp {
    constructor(__ins: ComponentInternalInstance) : super(__ins) {
        onLaunch(fun(_: OnLaunchOptions) {
            console.log("App Launch", " at App.uvue:5")
        }
        , __ins)
        onAppShow(fun(_: OnShowOptions) {
            console.log("App Show", " at App.uvue:8")
        }
        , __ins)
        onAppHide(fun() {
            console.log("App Hide", " at App.uvue:11")
        }
        , __ins)
        onLastPageBackPress(fun() {
            console.log("App LastPageBackPress", " at App.uvue:15")
            if (firstBackTime == 0) {
                uni_showToast(ShowToastOptions(title = "再按一次退出应用", position = "bottom"))
                firstBackTime = Date.now()
                setTimeout(fun(){
                    firstBackTime = 0
                }, 2000)
            } else if (Date.now() - firstBackTime < 2000) {
                firstBackTime = Date.now()
                uni_exit(null)
            }
        }
        , __ins)
        onExit(fun() {
            console.log("App Exit", " at App.uvue:32")
        }
        , __ins)
    }
    companion object {
        val styles: Map<String, Map<String, Map<String, Any>>> by lazy {
            normalizeCssStyles(utsArrayOf(
                styles0
            ))
        }
        val styles0: Map<String, Map<String, Map<String, Any>>>
            get() {
                return utsMapOf("uni-row" to padStyleMapOf(utsMapOf("flexDirection" to "row")), "uni-column" to padStyleMapOf(utsMapOf("flexDirection" to "column")))
            }
    }
}
val GenAppClass = CreateVueAppComponent(GenApp::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "app", name = "", inheritAttrs = true, inject = Map(), props = Map(), propsNeedCastKeys = utsArrayOf(), emits = Map(), components = Map(), styles = GenApp.styles)
}
, fun(instance): GenApp {
    return GenApp(instance)
}
)
val GenPagesDemo206Class = CreateVueComponent(GenPagesDemo206::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "page", name = "", inheritAttrs = GenPagesDemo206.inheritAttrs, inject = GenPagesDemo206.inject, props = GenPagesDemo206.props, propsNeedCastKeys = GenPagesDemo206.propsNeedCastKeys, emits = GenPagesDemo206.emits, components = GenPagesDemo206.components, styles = GenPagesDemo206.styles, setup = fun(props: ComponentPublicInstance): Any? {
        return GenPagesDemo206.setup(props as GenPagesDemo206)
    }
    )
}
, fun(instance): GenPagesDemo206 {
    return GenPagesDemo206(instance)
}
)
val GenPagesIndexIndexClass = CreateVueComponent(GenPagesIndexIndex::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "page", name = "", inheritAttrs = GenPagesIndexIndex.inheritAttrs, inject = GenPagesIndexIndex.inject, props = GenPagesIndexIndex.props, propsNeedCastKeys = GenPagesIndexIndex.propsNeedCastKeys, emits = GenPagesIndexIndex.emits, components = GenPagesIndexIndex.components, styles = GenPagesIndexIndex.styles)
}
, fun(instance): GenPagesIndexIndex {
    return GenPagesIndexIndex(instance)
}
)
val GenPagesDemo201Class = CreateVueComponent(GenPagesDemo201::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "page", name = "", inheritAttrs = GenPagesDemo201.inheritAttrs, inject = GenPagesDemo201.inject, props = GenPagesDemo201.props, propsNeedCastKeys = GenPagesDemo201.propsNeedCastKeys, emits = GenPagesDemo201.emits, components = GenPagesDemo201.components, styles = GenPagesDemo201.styles)
}
, fun(instance): GenPagesDemo201 {
    return GenPagesDemo201(instance)
}
)
val GenPagesDemo203Class = CreateVueComponent(GenPagesDemo203::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "page", name = "", inheritAttrs = GenPagesDemo203.inheritAttrs, inject = GenPagesDemo203.inject, props = GenPagesDemo203.props, propsNeedCastKeys = GenPagesDemo203.propsNeedCastKeys, emits = GenPagesDemo203.emits, components = GenPagesDemo203.components, styles = GenPagesDemo203.styles, setup = fun(props: ComponentPublicInstance): Any? {
        return GenPagesDemo203.setup(props as GenPagesDemo203)
    }
    )
}
, fun(instance): GenPagesDemo203 {
    return GenPagesDemo203(instance)
}
)
val GenPagesDemo202Class = CreateVueComponent(GenPagesDemo202::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "page", name = "", inheritAttrs = GenPagesDemo202.inheritAttrs, inject = GenPagesDemo202.inject, props = GenPagesDemo202.props, propsNeedCastKeys = GenPagesDemo202.propsNeedCastKeys, emits = GenPagesDemo202.emits, components = GenPagesDemo202.components, styles = GenPagesDemo202.styles)
}
, fun(instance): GenPagesDemo202 {
    return GenPagesDemo202(instance)
}
)
val GenPagesDemo204Class = CreateVueComponent(GenPagesDemo204::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "page", name = "", inheritAttrs = GenPagesDemo204.inheritAttrs, inject = GenPagesDemo204.inject, props = GenPagesDemo204.props, propsNeedCastKeys = GenPagesDemo204.propsNeedCastKeys, emits = GenPagesDemo204.emits, components = GenPagesDemo204.components, styles = GenPagesDemo204.styles, setup = fun(props: ComponentPublicInstance): Any? {
        return GenPagesDemo204.setup(props as GenPagesDemo204)
    }
    )
}
, fun(instance): GenPagesDemo204 {
    return GenPagesDemo204(instance)
}
)
val GenPagesDemo205Class = CreateVueComponent(GenPagesDemo205::class.java, fun(): VueComponentOptions {
    return VueComponentOptions(type = "page", name = "", inheritAttrs = GenPagesDemo205.inheritAttrs, inject = GenPagesDemo205.inject, props = GenPagesDemo205.props, propsNeedCastKeys = GenPagesDemo205.propsNeedCastKeys, emits = GenPagesDemo205.emits, components = GenPagesDemo205.components, styles = GenPagesDemo205.styles, setup = fun(props: ComponentPublicInstance): Any? {
        return GenPagesDemo205.setup(props as GenPagesDemo205)
    }
    )
}
, fun(instance): GenPagesDemo205 {
    return GenPagesDemo205(instance)
}
)
fun createApp(): UTSJSONObject {
    val app = createSSRApp(GenAppClass)
    return UTSJSONObject(Map<String, Any?>(utsArrayOf(
        utsArrayOf(
            "app",
            app
        )
    )))
}
fun main(app: IApp) {
    definePageRoutes()
    defineAppConfig()
    (createApp()["app"] as VueApp).mount(app, GenUniApp())
}
open class UniAppConfig : io.dcloud.uniapp.appframe.AppConfig {
    override var name: String = "uni-demo2"
    override var appid: String = "__UNI__659A61F"
    override var versionName: String = "1.0.0"
    override var versionCode: String = "100"
    override var uniCompilerVersion: String = "4.55"
    constructor() : super() {}
}
fun definePageRoutes() {
    __uniRoutes.push(UniPageRoute(path = "pages/demo2-06", component = GenPagesDemo206Class, meta = UniPageMeta(isQuit = true), style = utsMapOf("navigationBarTitleText" to "demo2-06")))
    __uniRoutes.push(UniPageRoute(path = "pages/index/index", component = GenPagesIndexIndexClass, meta = UniPageMeta(isQuit = false), style = utsMapOf("navigationBarTitleText" to "uni-app x")))
    __uniRoutes.push(UniPageRoute(path = "pages/demo2-01", component = GenPagesDemo201Class, meta = UniPageMeta(isQuit = false), style = utsMapOf("navigationBarTitleText" to "demo2-01")))
    __uniRoutes.push(UniPageRoute(path = "pages/demo2-03", component = GenPagesDemo203Class, meta = UniPageMeta(isQuit = false), style = utsMapOf("navigationBarTitleText" to "demo2-03")))
    __uniRoutes.push(UniPageRoute(path = "pages/demo2-02", component = GenPagesDemo202Class, meta = UniPageMeta(isQuit = false), style = utsMapOf("navigationBarTitleText" to "demo2-02")))
    __uniRoutes.push(UniPageRoute(path = "pages/demo2-04", component = GenPagesDemo204Class, meta = UniPageMeta(isQuit = false), style = utsMapOf("navigationBarTitleText" to "demo2-04")))
    __uniRoutes.push(UniPageRoute(path = "pages/demo2-05", component = GenPagesDemo205Class, meta = UniPageMeta(isQuit = false), style = utsMapOf("navigationBarTitleText" to "demo2-05")))
}
val __uniLaunchPage: Map<String, Any?> = utsMapOf("url" to "pages/demo2-06", "style" to utsMapOf("navigationBarTitleText" to "demo2-06"))
fun defineAppConfig() {
    __uniConfig.entryPagePath = "/pages/demo2-06"
    __uniConfig.globalStyle = utsMapOf("navigationBarTextStyle" to "black", "navigationBarTitleText" to "uni-app x", "navigationBarBackgroundColor" to "#F8F8F8", "backgroundColor" to "#F8F8F8")
    __uniConfig.getTabBarConfig = fun(): Map<String, Any>? {
        return null
    }
    __uniConfig.tabBar = __uniConfig.getTabBarConfig()
    __uniConfig.conditionUrl = ""
    __uniConfig.uniIdRouter = utsMapOf()
    __uniConfig.ready = true
}
open class GenUniApp : UniAppImpl() {
    open val vm: GenApp?
        get() {
            return getAppVm() as GenApp?
        }
    open val `$vm`: GenApp?
        get() {
            return getAppVm() as GenApp?
        }
}
fun getApp(): GenUniApp {
    return getUniApp() as GenUniApp
}
